


<?php $__env->startSection('container'); ?>
<h1><center>Hello World !</center></h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\coba-web\resources\views/home.blade.php ENDPATH**/ ?>