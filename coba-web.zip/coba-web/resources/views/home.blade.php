
@extends('layouts.main')

@section('container')
<h1><center>Hello World !</center></h1>
@endsection